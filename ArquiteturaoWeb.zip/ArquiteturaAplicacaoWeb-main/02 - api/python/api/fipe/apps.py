from django.apps import AppConfig


class FipeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fipe'
