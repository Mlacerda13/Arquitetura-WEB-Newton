package tech.buildrun.springsecurity.controller.dto;

public record FeedItemDto(long tweetId, String content, String username) {
}
