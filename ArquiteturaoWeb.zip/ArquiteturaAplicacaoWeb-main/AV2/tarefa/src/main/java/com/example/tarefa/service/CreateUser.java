package com.example.tarefa.service;

public record CreateUser(String username, String password) {
}