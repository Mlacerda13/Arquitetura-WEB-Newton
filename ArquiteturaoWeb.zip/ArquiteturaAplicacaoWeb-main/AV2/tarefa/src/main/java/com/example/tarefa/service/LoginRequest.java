package com.example.tarefa.service;
;

public record LoginRequest(String username, String password) {
}