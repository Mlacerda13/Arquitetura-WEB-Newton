package com.example.tarefa.service;

public record ListItem(long tweetId, String content, String username) {
}