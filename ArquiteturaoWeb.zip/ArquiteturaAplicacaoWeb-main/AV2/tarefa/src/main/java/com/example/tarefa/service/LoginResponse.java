package com.example.tarefa.service;

public record LoginResponse(String accessToken, Long expiresIn) {
}