package com.example.tarefa.service;

public record CreateTask(String content, String descricao, boolean concluida) {
}